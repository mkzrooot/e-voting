<?php
defined('BASEPATH') or die("No Access Allowed");
?>
<div class="text-center">
   <p>Terima kasih atas partisipasi anda...</p>
   <a href="./" class="btn btn-success btn-lg">Back to Home</a>
</div>
