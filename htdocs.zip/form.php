<?php defined('BASEPATH') or die("No Access Allowed");?>


        <form action="" method="post">
            <div class="form-group">
                <input type="number" class="form-control" placeholder="Masukkan Nomor Handphone :" required="NIS" name="nis"/>
            </div>
            <div class="row">
                <div class="text-right" style="padding-right:15px;">
                    <input type="submit" name="submit" class="btn btn-warning btn-lg" value="Submit">
                </div>
            </div>
        </form>